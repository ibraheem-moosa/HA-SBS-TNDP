#!/bin/sh

for i in *.py
do
    python2 $i > /dev/null

done
