// Copyright (C) 2005 Jochen K�pper <jochen@fhi-berlin.mpg.de>


#include "eoData.h"



// Local Variables:
// c-file-style: "Stroustrup"
// fill-column: 80
// End:
